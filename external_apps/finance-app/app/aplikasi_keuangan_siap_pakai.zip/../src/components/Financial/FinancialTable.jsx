import React, { useState, useEffect } from 'react';
import { Save, Plus, Trash2, ChevronDown, ChevronRight, Upload, AlertCircle } from 'lucide-react';
import { getFinancialData, saveFinancialData, MONTHS } from '../../models/financialData';
import { parseStandardizedExcel } from '../../services/excelParser';
import CurrencyInput, { formatCurrency } from './CurrencyInput';
import FinancialChart from './FinancialChart';
import RecapModal from './RecapModal';

const FinancialTable = ({ onTitleChange }) => {
    const [data, setData] = useState([]);
    const [filterSeksi, setFilterSeksi] = useState('UPT_PELATIHAN_PERTANIAN');
    const [filterProgram, setFilterProgram] = useState('');
    const [filterSumberDana, setFilterSumberDana] = useState('');
    const [filterSumberDanaPenyuluhan, setFilterSumberDanaPenyuluhan] = useState('SEMUA'); // For UPT View
    const [viewMonth, setViewMonth] = useState(''); // '' = All, 'jan' = Jan, etc.
    const [expandedGroups, setExpandedGroups] = useState(new Set());
    const [isRecapOpen, setIsRecapOpen] = useState(false);

    useEffect(() => {
        const loadedData = getFinancialData();
        setData(loadedData);
    }, []);

    // Update Title based on Filter
    useEffect(() => {
        if (onTitleChange) {
            if (filterSeksi === 'UPT_PELATIHAN_PERTANIAN') {
                onTitleChange('Laporan UPT Pelatihan Pertanian');
            } else if (filterSeksi) {
                onTitleChange(`Laporan Keuangan - ${filterSeksi}`);
            } else {
                onTitleChange('Sistem Realisasi Keuangan');
            }
        }
    }, [filterSeksi, onTitleChange]);

    const handleFileUpload = async (e) => {
        const file = e.target.files[0];
        if (!file) return;

        if (window.confirm('Import akan menimpa data yang ada. Lanjutkan?')) {
            try {
                const parsedData = await parseStandardizedExcel(file);
                setData(parsedData);
                saveFinancialData(parsedData);
                alert(`Berhasil import ${parsedData.length} data!`);
            } catch (err) {
                console.error(err);
                alert('Gagal import file: ' + err.message);
            }
        }
    };

    const handleSave = () => {
        saveFinancialData(data);
        alert('Data berhasil disimpan!');
    };

    const updateRecord = (id, field, value, monthKey = null, type = null) => {
        // Prevent editing in Aggregated Mode
        if (filterSeksi === 'UPT_PELATIHAN_PERTANIAN') {
            alert('Mode Gabungan UPT hanya untuk melihat data (Read Only). Silakan edit di masing-masing Seksi.');
            return;
        }

        const newData = data.map(item => {
            if (item.id === id) {
                if (monthKey) {
                    // Update Realisasi
                    return {
                        ...item,
                        realisasi: {
                            ...item.realisasi,
                            [monthKey]: {
                                ...item.realisasi[monthKey],
                                [type]: Number(value)
                            }
                        }
                    };
                } else if (field.includes('.')) {
                    // Update Nested (e.g. anggaran.papbd)
                    const [parent, child] = field.split('.');
                    return {
                        ...item,
                        [parent]: {
                            ...item[parent],
                            [child]: Number(value)
                        }
                    };
                } else {
                    // Update Direct
                    return { ...item, [field]: value };
                }
            }
            return item;
        });
        setData(newData);
    };

    // --- Aggregation Helper ---
    const aggregateData = (rows) => {
        const map = new Map();

        rows.forEach(item => {
            const key = item.kodeRekening;
            if (!map.has(key)) {
                // Clone the first item as base, reset numbers
                map.set(key, {
                    ...item,
                    id: `agg-${item.kodeRekening}`, // Virtual ID
                    anggaran: { ...item.anggaran }, // Clone
                    realisasi: JSON.parse(JSON.stringify(item.realisasi)) // Deep clone
                });
            } else {
                const existing = map.get(key);
                // Sum Anggaran
                existing.anggaran.sebelum += (item.anggaran.sebelum || 0);
                existing.anggaran.setelah += (item.anggaran.setelah || 0);
                existing.anggaran.papbd += (item.anggaran.papbd || 0);

                // Sum Realisasi
                Object.keys(existing.realisasi).forEach(mKey => {
                    existing.realisasi[mKey].dkkb += (item.realisasi[mKey]?.dkkb || 0);
                    existing.realisasi[mKey].realisasi += (item.realisasi[mKey]?.realisasi || 0);
                });
            }
        });

        return Array.from(map.values());
    };

    // --- Filtering Logic ---
    const uniqueSeksi = [...new Set(data.map(d => d.seksi).filter(Boolean))].sort();
    const uniqueSumberDana = [...new Set(data.map(d => d.sumberDana).filter(Boolean))].sort();

    // Dynamic Program Options based on UPT selection (Only for Normal View)
    let availablePrograms = [];
    if (filterSeksi !== 'UPT_PELATIHAN_PERTANIAN') {
        availablePrograms = [...new Set(data.filter(d => !filterSeksi || d.seksi === filterSeksi).map(d => d.program).filter(Boolean))].sort();
    }

    // --- Data Preparation ---
    let dataPenyuluhan = [];
    let dataPenunjang = [];
    let dataNormal = [];

    if (filterSeksi === 'UPT_PELATIHAN_PERTANIAN') {
        // 1. Penyuluhan (Pelatihan + Pengembangan)
        const rawPenyuluhan = data.filter(item =>
            ['SEKSI PELATIHAN', 'SEKSI PENGEMBANGAN'].includes(item.seksi) &&
            item.program.includes('PENYULUHAN') &&
            (filterSumberDanaPenyuluhan === 'SEMUA' || item.sumberDana === filterSumberDanaPenyuluhan)
        );
        dataPenyuluhan = aggregateData(rawPenyuluhan).filter(item => item.anggaran.papbd > 0);

        // 2. Penunjang (Tata Usaha) - ONLY PAD MURNI
        const rawPenunjang = data.filter(item =>
            ['SUB BAGIAN TATA USAHA'].includes(item.seksi) &&
            item.program.includes('PENUNJANG') &&
            item.sumberDana === 'PAD MURNI'
        );
        dataPenunjang = aggregateData(rawPenunjang).filter(item => item.anggaran.papbd > 0);

    } else {
        // Normal View
        dataNormal = data.filter(item => {
            const matchesFilters = (
                (!filterSeksi || item.seksi === filterSeksi) &&
                (!filterProgram || item.program === filterProgram) &&
                (!filterSumberDana || item.sumberDana === filterSumberDana)
            );

            if (filterSeksi && matchesFilters) {
                return item.anggaran.papbd > 0;
            }
            return matchesFilters;
        });
    }

    const visibleMonths = viewMonth ? MONTHS.filter(m => m.key === viewMonth) : MONTHS;

    // YTD Calculation Logic
    // If a month is selected, we calculate totals from Jan up to that month.
    // If no month selected, we calculate all months.
    const calculationMonths = viewMonth
        ? MONTHS.slice(0, MONTHS.findIndex(m => m.key === viewMonth) + 1)
        : MONTHS;

    const calculationMonthKeys = calculationMonths.map(m => m.key);

    // --- Chart Data Preparation ---
    let chartData = [];
    let chartTitle = '';

    if (filterSeksi === 'UPT_PELATIHAN_PERTANIAN') {
        chartData = [...dataPenyuluhan, ...dataPenunjang];
        chartTitle = 'Total Realisasi Anggaran - UPT PELATIHAN PERTANIAN';
    } else {
        chartData = dataNormal;
        chartTitle = filterSeksi ? `Total Realisasi Anggaran - ${filterSeksi}` : 'Total Realisasi Anggaran - Semua Seksi';
    }

    // --- Calculation Helper ---
    const calculateRow = (item) => {
        let totalRealisasi = 0;

        // Sum only calculationMonths
        calculationMonthKeys.forEach(key => {
            totalRealisasi += (item.realisasi[key]?.realisasi || 0);
        });

        const sisaAnggaran = (item.anggaran.papbd || 0) - totalRealisasi;
        const persen = item.anggaran.papbd ? (totalRealisasi / item.anggaran.papbd) * 100 : 0;

        return { totalRealisasi, sisaAnggaran, persen };
    };

    const calculateSummary = (rows) => {
        return rows.reduce((acc, item) => {
            const { totalRealisasi, sisaAnggaran } = calculateRow(item);
            acc.anggaranPapbd += (item.anggaran.papbd || 0);
            acc.totalRealisasi += totalRealisasi;
            acc.sisaAnggaran += sisaAnggaran;

            MONTHS.forEach(m => {
                acc.months[m.key].dkkb += (item.realisasi[m.key]?.dkkb || 0);
                acc.months[m.key].realisasi += (item.realisasi[m.key]?.realisasi || 0);
            });

            return acc;
        }, {
            anggaranPapbd: 0,
            totalRealisasi: 0,
            sisaAnggaran: 0,
            months: MONTHS.reduce((mAcc, m) => ({ ...mAcc, [m.key]: { dkkb: 0, realisasi: 0 } }), {})
        });
    };

    // --- Render Helper ---
    const renderTable = (tableData, title, customHeader = null) => {
        const summary = calculateSummary(tableData);
        const summaryPersen = summary.anggaranPapbd ? (summary.totalRealisasi / summary.anggaranPapbd) * 100 : 0;

        return (
            <div style={{ marginBottom: '2rem', overflowX: 'auto', borderRadius: '0.75rem', border: '1px solid #e2e8f0', boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)' }}>
                {title && (
                    <div style={{ padding: '1rem', backgroundColor: '#f1f5f9', borderBottom: '1px solid #e2e8f0', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                        <h3 style={{ fontSize: '1rem', fontWeight: 'bold', color: '#334155', margin: 0 }}>{title}</h3>
                        {customHeader}
                    </div>
                )}
                <table className="table table-xs" style={{ width: '100%', borderCollapse: 'separate', borderSpacing: 0, fontSize: '12px', backgroundColor: 'white' }}>
                    <thead style={{ backgroundColor: '#f8fafc', color: '#334155', fontWeight: '700' }}>
                        <tr>
                            <th style={{ borderBottom: '2px solid #cbd5e1', padding: '12px', minWidth: '120px', textAlign: 'left' }}>KODE REKENING</th>
                            <th style={{ borderBottom: '2px solid #cbd5e1', padding: '12px', minWidth: '300px', textAlign: 'left' }}>URAIAN</th>
                            <th style={{ borderBottom: '2px solid #cbd5e1', padding: '12px', textAlign: 'right', backgroundColor: '#e2e8f0' }}>ANGGARAN PAPBD</th>
                            {visibleMonths.map(m => (
                                <th key={m.key} style={{ borderBottom: '2px solid #cbd5e1', padding: '8px', textAlign: 'center', borderLeft: '1px solid #e2e8f0' }}>{m.label.toUpperCase()}</th>
                            ))}
                            <th style={{ borderBottom: '2px solid #cbd5e1', padding: '12px', minWidth: '120px', textAlign: 'right', borderLeft: '2px solid #cbd5e1' }}>SISA ANGGARAN</th>
                            <th style={{ borderBottom: '2px solid #cbd5e1', padding: '12px', minWidth: '120px', textAlign: 'right' }}>TOTAL REALISASI</th>
                            <th style={{ borderBottom: '2px solid #cbd5e1', padding: '12px', textAlign: 'right' }}>%</th>
                        </tr>
                    </thead>
                    <tbody>
                        {tableData.length === 0 ? (
                            <tr>
                                <td colSpan={10 + visibleMonths.length} style={{ padding: '2rem', textAlign: 'center', color: '#94a3b8' }}>Tidak ada data.</td>
                            </tr>
                        ) : (
                            tableData.map((item, index) => {
                                const { totalRealisasi, sisaAnggaran, persen } = calculateRow(item);
                                const isEven = index % 2 === 0;
                                return (
                                    <tr key={item.id} style={{ backgroundColor: isEven ? '#ffffff' : '#f8fafc', transition: 'background-color 0.2s' }} className="hover:bg-blue-50">
                                        <td style={{ borderBottom: '1px solid #e2e8f0', padding: '8px 12px', fontFamily: 'monospace', color: '#475569' }}>{item.kodeRekening}</td>
                                        <td style={{ borderBottom: '1px solid #e2e8f0', padding: '8px 12px', fontWeight: '500', color: '#1e293b' }}>{item.uraian}</td>

                                        <td style={{ borderBottom: '1px solid #e2e8f0', padding: '0', backgroundColor: isEven ? '#f1f5f9' : '#e2e8f0' }}>
                                            <CurrencyInput
                                                value={item.anggaran.papbd}
                                                onChange={(val) => updateRecord(item.id, 'anggaran.papbd', val)}
                                                style={{ width: '100%', border: 'none', padding: '8px 12px', fontWeight: 'bold', backgroundColor: 'transparent', color: '#0f172a' }}
                                                disabled={filterSeksi === 'UPT_PELATIHAN_PERTANIAN'}
                                            />
                                        </td>

                                        {visibleMonths.map(m => (
                                            <React.Fragment key={m.key}>
                                                <td style={{ borderBottom: '1px solid #e2e8f0', padding: '0', borderLeft: '1px solid #f1f5f9' }}>
                                                    <CurrencyInput
                                                        value={item.realisasi[m.key]?.realisasi || 0}
                                                        onChange={(val) => updateRecord(item.id, null, val, m.key, 'realisasi')}
                                                        style={{ width: '100%', minWidth: '80px', border: 'none', padding: '8px', fontSize: '11px', backgroundColor: 'transparent', color: '#334155' }}
                                                        disabled={filterSeksi === 'UPT_PELATIHAN_PERTANIAN'}
                                                    />
                                                </td>
                                            </React.Fragment>
                                        ))}

                                        <td style={{ borderBottom: '1px solid #e2e8f0', padding: '8px 12px', textAlign: 'right', borderLeft: '2px solid #f1f5f9', color: sisaAnggaran < 0 ? '#ef4444' : '#1e293b' }}>
                                            {formatCurrency(sisaAnggaran)}
                                        </td>
                                        <td style={{ borderBottom: '1px solid #e2e8f0', padding: '8px 12px', textAlign: 'right', fontWeight: 'bold', color: '#0f172a' }}>
                                            {formatCurrency(totalRealisasi)}
                                        </td>
                                        <td style={{ borderBottom: '1px solid #e2e8f0', padding: '8px 12px', textAlign: 'right', color: '#475569' }}>
                                            {persen.toFixed(2)}%
                                        </td>
                                    </tr>
                                );
                            })
                        )}
                    </tbody>
                    <tfoot style={{ backgroundColor: '#1e293b', color: 'white', fontWeight: 'bold' }}>
                        <tr>
                            <td colSpan="2" style={{ padding: '12px', textAlign: 'center', borderTop: '2px solid #0f172a' }}>TOTAL</td>
                            <td style={{ padding: '12px', textAlign: 'right', borderTop: '2px solid #0f172a', backgroundColor: '#334155' }}>{formatCurrency(summary.anggaranPapbd)}</td>

                            {visibleMonths.map(m => (
                                <React.Fragment key={m.key}>
                                    <td style={{ padding: '12px', textAlign: 'right', borderTop: '2px solid #0f172a', borderLeft: '1px solid #475569' }}>{formatCurrency(summary.months[m.key].realisasi)}</td>
                                </React.Fragment>
                            ))}

                            <td style={{ padding: '12px', textAlign: 'right', borderTop: '2px solid #0f172a', borderLeft: '2px solid #475569' }}>{formatCurrency(summary.sisaAnggaran)}</td>
                            <td style={{ padding: '12px', textAlign: 'right', borderTop: '2px solid #0f172a' }}>{formatCurrency(summary.totalRealisasi)}</td>
                            <td style={{ padding: '12px', textAlign: 'right', borderTop: '2px solid #0f172a' }}>{summaryPersen.toFixed(2)}%</td>
                        </tr>
                    </tfoot>
                </table >
            </div >
        );
    };

    return (
        <div className="financial-table-container" style={{ padding: '1.5rem', backgroundColor: '#f8fafc', minHeight: '100vh', fontFamily: 'Inter, sans-serif' }}>

            {/* Visualization Chart */}
            {(filterSeksi || filterProgram) && (
                <FinancialChart data={chartData} title={chartTitle} months={calculationMonthKeys} />
            )}

            {/* Controls Bar */}
            <div style={{ marginBottom: '1.5rem', display: 'flex', flexDirection: 'column', gap: '1rem' }}>


                <div style={{ display: 'flex', gap: '1rem', alignItems: 'center', flexWrap: 'wrap', justifyContent: 'flex-end' }}>
                    <div style={{ display: 'flex', gap: '0.5rem' }}>
                        {/* Recap Button */}
                        <button
                            className="btn btn-sm"
                            onClick={() => setIsRecapOpen(true)}
                            style={{ backgroundColor: '#8b5cf6', borderColor: '#8b5cf6', color: 'white' }}
                        >
                            <AlertCircle size={16} style={{ marginRight: '0.5rem' }} /> Rekapitulasi
                        </button>

                        <button className="btn btn-primary btn-sm" onClick={handleSave} style={{ backgroundColor: '#2563eb', borderColor: '#2563eb', color: 'white' }}>
                            <Save size={16} style={{ marginRight: '0.5rem' }} /> Simpan
                        </button>

                        <div style={{ position: 'relative' }}>
                            <input
                                type="file"
                                accept=".xlsx, .xls"
                                onChange={handleFileUpload}
                                style={{ position: 'absolute', top: 0, left: 0, width: '100%', height: '100%', opacity: 0, cursor: 'pointer' }}
                            />
                            <button className="btn btn-secondary btn-sm" style={{ backgroundColor: '#fff', borderColor: '#cbd5e1', color: '#475569' }}>
                                <Upload size={16} style={{ marginRight: '0.5rem' }} /> Import Excel
                            </button>
                        </div>
                    </div>
                </div>

                {/* Recap Modal */}
                <RecapModal
                    isOpen={isRecapOpen}
                    onClose={() => setIsRecapOpen(false)}
                    data={data}
                    monthKey={viewMonth}
                    calculationMonthKeys={calculationMonthKeys}
                    uniqueSeksi={uniqueSeksi}
                />

                {/* Filters */}
                <div style={{ display: 'flex', gap: '1rem', flexWrap: 'wrap', padding: '1rem', backgroundColor: 'white', borderRadius: '0.75rem', border: '1px solid #e2e8f0', boxShadow: '0 1px 3px rgba(0,0,0,0.05)' }}>
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '0.05rem' }}>
                        <label style={{ fontSize: '0.75rem', fontWeight: 'bold', color: '#64748b' }}>UNIT KERJA / SEKSI</label>
                        <select className="select select-bordered select-sm" value={filterSeksi} onChange={e => setFilterSeksi(e.target.value)} style={{ minWidth: '250px', fontWeight: '600', color: '#334155' }}>
                            <option value="UPT_PELATIHAN_PERTANIAN" style={{ fontWeight: 'bold', color: '#2563eb' }}>UPT PELATIHAN PERTANIAN (GABUNGAN)</option>
                            <option disabled>----------------</option>
                            {uniqueSeksi.map(s => <option key={s} value={s}>{s}</option>)}
                        </select>
                    </div>

                    {/* Normal View Filters */}
                    {filterSeksi !== 'UPT_PELATIHAN_PERTANIAN' && (
                        <>
                            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.05rem' }}>
                                <label style={{ fontSize: '0.75rem', fontWeight: 'bold', color: '#64748b' }}>PROGRAM</label>
                                <select className="select select-bordered select-sm" value={filterProgram} onChange={e => setFilterProgram(e.target.value)} style={{ maxWidth: '300px' }}>
                                    <option value="">Semua Program</option>
                                    {availablePrograms.map(p => <option key={p} value={p}>{p}</option>)}
                                </select>
                            </div>

                            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.05rem' }}>
                                <label style={{ fontSize: '0.75rem', fontWeight: 'bold', color: '#64748b' }}>SUMBER DANA</label>
                                <select className="select select-bordered select-sm" value={filterSumberDana} onChange={e => setFilterSumberDana(e.target.value)}>
                                    <option value="">Semua Sumber Dana</option>
                                    {uniqueSumberDana.map(s => <option key={s} value={s}>{s}</option>)}
                                </select>
                            </div>
                        </>
                    )}

                    <div style={{ display: 'flex', flexDirection: 'column', gap: '0.05rem' }}>
                        <label style={{ fontSize: '0.75rem', fontWeight: 'bold', color: '#64748b' }}>PERIODE</label>
                        <select className="select select-bordered select-sm" value={viewMonth} onChange={e => setViewMonth(e.target.value)}>
                            <option value="">Semua Bulan</option>
                            {MONTHS.map(m => <option key={m.key} value={m.key}>{m.label}</option>)}
                        </select>
                    </div>
                </div>
            </div>

            {/* Content Render */}
            {filterSeksi === 'UPT_PELATIHAN_PERTANIAN' ? (
                <>
                    {renderTable(dataPenyuluhan, 'PROGRAM PENYULUHAN PERTANIAN', (
                        <select
                            className="select select-bordered select-xs"
                            value={filterSumberDanaPenyuluhan}
                            onChange={e => setFilterSumberDanaPenyuluhan(e.target.value)}
                            style={{ fontWeight: 'bold' }}
                        >
                            <option value="SEMUA">SEMUA SUMBER DANA</option>
                            <option value="PAD MURNI">PAD MURNI</option>
                            <option value="DBHCHT">DBHCHT</option>
                        </select>
                    ))}

                    {renderTable(dataPenunjang, 'PROGRAM PENUNJANG URUSAN PEMERINTAHAN DAERAH PROVINSI', (
                        <span className="badge badge-neutral">PAD MURNI</span>
                    ))}
                </>
            ) : (
                renderTable(dataNormal, '')
            )}
        </div>
    );
};

export default FinancialTable;
