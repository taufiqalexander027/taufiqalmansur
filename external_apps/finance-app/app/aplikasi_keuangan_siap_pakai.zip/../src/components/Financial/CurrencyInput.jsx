import React from 'react';

export const formatCurrency = (value) => {
    if (value === null || value === undefined || value === '') return '';
    // Use 'decimal' style to get just the number with separators
    return new Intl.NumberFormat('id-ID', {
        style: 'decimal',
        minimumFractionDigits: 0,
        maximumFractionDigits: 0
    }).format(value);
};

const CurrencyInput = ({ value, onChange, style, ...props }) => {
    // Format the value for display
    const displayValue = value !== 0 && !value ? '' : formatCurrency(value);

    const handleChange = (e) => {
        // Remove non-digit characters
        const rawValue = e.target.value.replace(/[^0-9]/g, '');
        const numericValue = rawValue ? parseInt(rawValue, 10) : 0;
        onChange(numericValue);
    };

    return (
        <input
            type="text"
            value={displayValue}
            onChange={handleChange}
            style={{
                ...style,
                textAlign: 'right'
            }}
            {...props}
        />
    );
};

export default CurrencyInput;
