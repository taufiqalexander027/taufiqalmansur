import React, { useState } from 'react';
import FinancialTable from './components/Financial/FinancialTable';
import AddRekeningForm from './components/Financial/AddRekeningForm';
import { Plus } from 'lucide-react';

function App() {
  const [showAddForm, setShowAddForm] = useState(false);
  const [refreshKey, setRefreshKey] = useState(0);
  const [pageTitle, setPageTitle] = useState('Sistem Realisasi Keuangan');

  const handleSaveSuccess = () => {
    setShowAddForm(false);
    setRefreshKey(prev => prev + 1); // Force table refresh
  };

  return (
    <div className="container mx-auto p-4">
      <header style={{ marginBottom: '2rem', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <h1 style={{ fontSize: '1.5rem', fontWeight: 'bold' }}>{pageTitle}</h1>
        <button className="btn btn-primary" onClick={() => setShowAddForm(true)}>
          <Plus size={16} style={{ marginRight: '0.5rem' }} /> Tambah Rekening
        </button>
      </header>

      {showAddForm && (
        <div style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: 'rgba(0,0,0,0.5)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 50 }}>
          <AddRekeningForm onSaveSuccess={handleSaveSuccess} onCancel={() => setShowAddForm(false)} />
        </div>
      )}

      <FinancialTable key={refreshKey} onTitleChange={setPageTitle} />
    </div>
  );
}

export default App;
